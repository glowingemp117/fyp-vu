const User = require('../models/User');
const ApiResponse = require('../utils/ApiResponse');

// @desc    Get my profile
// @route   GET /api/users/me
exports.getMyProfile = async (req, res, next) => {
  try {
    return ApiResponse.success(res, req.user.toSafeObject());
  } catch (error) {
    next(error);
  }
};

// @desc    Update profile
// @route   PUT /api/users/me
exports.updateProfile = async (req, res, next) => {
  try {
    const allowedUpdates = ['name', 'phone', 'city', 'avatar', 'timezone'];
    const updates = {};

    allowedUpdates.forEach((field) => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const user = await User.findByIdAndUpdate(req.user._id, updates, {
      new: true,
      runValidators: true,
    });

    return ApiResponse.success(res, user.toSafeObject(), 'Profile updated successfully');
  } catch (error) {
    next(error);
  }
};

// @desc    Update FCM token
// @route   PUT /api/users/fcm-token
exports.updateFcmToken = async (req, res, next) => {
  try {
    const { fcmToken } = req.body;
    await User.findByIdAndUpdate(req.user._id, { fcmToken });
    return ApiResponse.success(res, null, 'FCM token updated');
  } catch (error) {
    next(error);
  }
};
